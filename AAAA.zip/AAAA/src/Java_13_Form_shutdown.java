import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;


import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Java_13_Form_shutdown extends Frame {
	Java_13_Form_shutdown(){
        super("內部類別");
        this.setSize(500,500);
        this.addWindowListener(new wap()); //將內部類別註冊關於視窗的事件
    }
    public static void main(String[] args) {
    	Java_13_Form_shutdown frm = new Java_13_Form_shutdown();
        frm.setVisible(true);
    }
    class wap extends WindowAdapter{
        public void windowClosing(WindowEvent e){
            System.exit(0);
        }
    }
}